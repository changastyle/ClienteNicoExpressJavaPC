package XMLAPI;
public class LeerXML 
{
        public static void main(String[] args) 
        {
                System.out.println( XMLHandler.leerInt("importeMinimoPorApuesta")  );
        }
        
}
