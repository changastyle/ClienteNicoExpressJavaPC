package server;

public class MainServer
{
    public static void main(String[] args)
    {
        ManejadorServer manejadorServer = new ManejadorServer();        
    }
    
}
